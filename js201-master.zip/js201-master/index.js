/*
 * This is index.js
 *
 * Start by modifying the id, fn and sn functions to return
 * information about you, then open index.html to check what
 * else you have to do, adding functions to the end of this
 * file as necessary.
 *
 * NB: all code you write this year should use strict mode, so
 * we've enabled that by default with the first line of code.
 */

'use strict';

function id() {
  // e.g. return "UP654321";
}

function fn() {
  return 'Replace This With Your First Name';
}

function sn() {
  return 'Replace This With Your Surname';
}

function example() {
  // replace this example with
  // your first function then
  // add more below as necessary.

}
